#include "main.h"
// CANDLE DEFINE
struct CandleData{
  string time;
  string OP;
  string HP;
  string LP;
  string CP;
};
struct CandleNode{
  CandleData candle_data;
  CandleNode* link;
  CandleNode():link(NULL){}
  CandleNode(CandleData& a):candle_data(a),link(NULL){}
};
class CandleList{
  CandleNode* head_can;
  int count;
  public:
  CandleList():head_can(NULL),count(0){}
  ~CandleList();
  CandleNode* getHeadCandle(){return head_can;}
  bool isEmptyCandle(){return head_can==NULL;}
  int length(){return count;}
  void cleanCandle();
  int insertCandle(CandleData& a);
  bool find_can(string time, int& idx);
  bool find_periodTime(string time1, string time2, int* &arr, int &numbers);
  int removeCandle(int i);
  int removeHeadCandle();
  bool isSpiningtop(int i);
  bool isMarubozu(int i);
  bool isDJC1(int i);
  bool isDJC2(int i);
  bool isDJC3(int i);
  bool isDJC4(int i);
  bool isDJ(int i);
  bool isEGbullish(int i,int j);
  bool isEGbearish(int i,int j);
};

// CURRENCY DEFINE

struct CurrencyData{
  string BC;
  string QC;
  CandleList* candle_list=new CandleList();
};

struct CurrencyNode{
  CurrencyData currency_data;
  CurrencyNode* link;
  CurrencyNode():link(NULL){}
  CurrencyNode(CurrencyData& a):currency_data(a),link(NULL){}
};
class CurrencyList{
  CurrencyNode* head;
  int count;
  public:
  CurrencyList():head(NULL),count(0){}
  ~CurrencyList();
  CurrencyNode* getHead(){return head;}
  bool isEmpty(){return head==NULL;}
  int length(){return count;}
  void clean();
  bool find(string BC, string QC, int& idx);
  // find an element has BC and QC similar. return the position idx of the element if is true, -1 if is false;
  int insert_currency(CurrencyData& a);
};
class ProcessData {
	private:
    CurrencyList* data;
		static const int MAXSIZECODE = 8;
		static int split(string line,string* &sp);
	public:
		ProcessData();
		~ProcessData();
		int process(string line);
		int insert(const string* sp,const int n);
    int remove(const string* sp,const int n);
    int update(const string* sp,const int n);
    int stcandle(const string* sp,const int n);
    int mbcandle(const string* sp,const int n);
    int djcandle(const string* sp,const int n);
    int djCodeC1(const string* sp,const int n);
    int djCodeC2(const string* sp,const int n);
    int djCodeC3(const string* sp,const int n);
    int djCodeC4(const string* sp,const int n);
    int djNonCode(const string* sp,const int n);
    int egcandle(const string*sp,const int n);
    
};