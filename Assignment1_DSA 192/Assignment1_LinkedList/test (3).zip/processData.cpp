#include "processData.h"

enum CodeValue {insCode, delCode, updCode, stCode, mbCode, djCode, egCode, comCode};

static map<string, CodeValue> s_mapCodeValues = {
	{"INS",insCode},
	{"DEL",delCode},
	{"UPD",updCode},
	{"ST",stCode},
	{"MB",mbCode},
	{"DJ",djCode},
	{"EG",egCode}
};
// CANDLE Implement

void CandleList::cleanCandle(){
  if(isEmptyCandle()) return;
  CandleNode* currItem=this->head_can;
  while(currItem!=NULL){
    this->head_can=currItem->link;
    currItem=NULL;
    delete currItem;
    currItem=this->head_can;
  }
  this->count=0;
}

CandleList::~CandleList(){
  this->cleanCandle();
}

int CandleList::insertCandle(CandleData& a){
  if(this->isEmptyCandle()){
    CandleNode* p_New = new CandleNode(a);
    this->head_can=p_New;
    this->count++;
  }else{
    CandleNode* p_Walk=this->head_can;
    while(p_Walk->link!=NULL){
      p_Walk=p_Walk->link;
    }
    CandleNode* p_New = new CandleNode(a);
    p_Walk->link=p_New;
    this->count++;
  }
  return 0;
  
}
bool CandleList::find_can(string time,int& idx){
  if(this->isEmptyCandle()) return false;
  int index=0;
  CandleNode* p_Walk=this->head_can;
  while(p_Walk!=NULL){
    if(p_Walk->candle_data.time.compare(time)==0){
      idx=index;
      return true;
    }
    index++;
    p_Walk=p_Walk->link;
  }
  return false;
}
bool CandleList::find_periodTime(string time1, string time2, int *&arr, int &numbers){
   if(this->isEmptyCandle()) return false;
  int x=this->length();
  arr=new int[x];
  int i=0;
  int candle_pos=0;
  CandleNode* p_Walk=this->getHeadCandle();
  while(p_Walk!=NULL){
    if((p_Walk->candle_data.time.compare(time1)>=0)&&(p_Walk->candle_data.time.compare(time2))<=0){
      arr[i]=candle_pos;
      i++;
      numbers=i;
    }
    candle_pos++;
    p_Walk=p_Walk->link;
  }
  if(i==0) return false;
  return true;
}
int CandleList::removeHeadCandle(){
  if(this->isEmptyCandle()==false){
    CandleNode* currItem=this->head_can;
    this->head_can=currItem->link;
    currItem=NULL;
    delete currItem;
    this->count--;
    return 0;
  }
  return -1;
}
int CandleList::removeCandle(int i){
  if(this->isEmptyCandle()||i>this->length()) return -1;
  if(i==0){
    this->removeHeadCandle();
  }else{
    CandleNode* currItem=this->getHeadCandle();
    CandleNode* preItem=currItem;
    int count=0;
    while(count<i){
      count++;
      preItem=currItem;
      currItem=currItem->link;
    }
    preItem->link=currItem->link;
    currItem=NULL;
    delete currItem;
    this->count--;
    return 0;
  }
  return -1;
}

bool CandleList::isSpiningtop(int i){
  if(this->isEmptyCandle()||i>this->length()) return false;
  CandleNode* p_Walk=this->head_can;
  int count=0;
  while(count<i){
    p_Walk=p_Walk->link;
    count++;
  }
  float OP=stof(p_Walk->candle_data.OP);
  float CP=stof(p_Walk->candle_data.CP);
  if(abs(OP-CP)<0.00005||0.00005-abs(OP-CP)<0.0000001)
    return true;
  return false;
}

bool CandleList::isMarubozu(int i){
  if(this->isEmptyCandle()||i>this->length()) return false;
  CandleNode* p_Walk=this->head_can;
  int count=0;
  while(count<i){
    p_Walk=p_Walk->link;
    count++;
  }
  float OP=stof(p_Walk->candle_data.OP);
  float HP=stof(p_Walk->candle_data.HP);
  float LP=stof(p_Walk->candle_data.LP);
  float CP=stof(p_Walk->candle_data.CP);
  if(OP==LP&&CP==HP&&abs(OP-CP)-0.00005>0.0000001){
    return true;
  }else if(OP==HP&&CP==LP&&abs(OP-CP)-0.00005>0.0000001){
    return true;
  }
  return false;
}
bool CandleList::isDJC1(int i){
  if(this->isEmptyCandle()||i>this->length()) return false;
  CandleNode* p_Walk=this->head_can;
  int count=0;
  while(count<i){
    p_Walk=p_Walk->link;
    count++;
  }
  float OP=stof(p_Walk->candle_data.OP);
  float HP=stof(p_Walk->candle_data.HP);
  float LP=stof(p_Walk->candle_data.LP);
  float CP=stof(p_Walk->candle_data.CP);
  /*if((OP>CP||OP==CP)&&(OP-CP<0.00002||OP-CP-0.00002<0.0000001)){
    if(HP-OP-0.00005>0.0000001&&CP-LP-0.00005>0.0000001) 
      return true;
  }else if((CP>OP||CP==OP)&&(CP-OP<0.00002||CP-OP-0.00002<0.0000001)){
    if(HP-CP-0.00005>0.0000001&&OP-LP-0.00005>0.0000001) 
      return true;
  } */
  if(OP>=CP&&(OP-CP<0.00002||OP-CP-0.00002<0.0000001)){
    if(HP-OP-0.00005>0.0000001&&CP-LP-0.00005>0.0000001) 
      return true;
  }else if(CP>=OP&&(CP-OP<0.00002||CP-OP-0.00002<0.0000001)){
    if(HP-CP-0.00005>0.0000001&&OP-LP-0.00005>0.0000001) 
      return true;
  }
  return false;
}
bool CandleList::isDJC2(int i){
  if(this->isEmptyCandle()||i>this->length()) return false;
  CandleNode* p_Walk=this->head_can;
  int count=0;
  while(count<i){
    p_Walk=p_Walk->link;
    count++;
  }
  float OP=stof(p_Walk->candle_data.OP);
  float HP=stof(p_Walk->candle_data.HP);
  float LP=stof(p_Walk->candle_data.LP);
  float CP=stof(p_Walk->candle_data.CP);
  if(abs(OP-CP)<0.00002||abs(OP-CP)-0.00002<0.0000001){
    if(OP==HP&&CP-LP-0.00005>0.0000001) return true;
    else if(CP==HP&&OP-LP-0.00005>0.0000001) return true;
  }
  return false;
}
bool CandleList::isDJC3(int i){
  if(this->isEmptyCandle()||i>this->length()) return false;
  CandleNode* p_Walk=this->head_can;
  int count=0;
  while(count<i){
    p_Walk=p_Walk->link;
    count++;
  }
  float OP=stof(p_Walk->candle_data.OP);
  float HP=stof(p_Walk->candle_data.HP);
  float LP=stof(p_Walk->candle_data.LP);
  float CP=stof(p_Walk->candle_data.CP);
  if(abs(OP-CP)<0.00002||abs(OP-CP)-0.00002<0.0000001){
    if(OP==LP&&HP-CP-0.00005>0.0000001) return true;
    else if(CP==LP&&HP-OP-0.00005>0.0000001) return true;
  }
  return false;
}
bool CandleList::isDJC4(int i){
  if(this->isEmptyCandle()||i>this->length()) return false;
  CandleNode* p_Walk=this->head_can;
  int count=0;
  while(count<i){
    p_Walk=p_Walk->link;
    count++;
  }
  float OP=stof(p_Walk->candle_data.OP);
  float HP=stof(p_Walk->candle_data.HP);
  float LP=stof(p_Walk->candle_data.LP);
  float CP=stof(p_Walk->candle_data.CP);
  if(OP==HP&&OP==LP&&OP==CP) 
    return true;
  return false;
}
bool CandleList::isDJ(int i){
  if(this->isEmptyCandle()||i>this->length()) return false;
  CandleNode* p_Walk=this->head_can;
  int count=0;
  while(count<i){
    p_Walk=p_Walk->link;
    count++;
  }
  double OP=stod(p_Walk->candle_data.OP);
  double CP=stod(p_Walk->candle_data.CP);
   if(abs(OP-CP)<0.00002||abs(OP-CP)-0.00002<0.0000001){
    return true;
  }

  return false;
}
bool CandleList::isEGbullish(int i,int j){
  if(this->isEmptyCandle()||i>this->length()||j>this->length()) return false;
  CandleNode* p_Walk=this->head_can;
  int count=0;
  while(count<i){
    p_Walk=p_Walk->link;
    count++;
  }
  float OP1=stof(p_Walk->candle_data.OP);
  float HP1=stof(p_Walk->candle_data.HP);
  float LP1=stof(p_Walk->candle_data.LP);
  float CP1=stof(p_Walk->candle_data.CP);
  if(OP1>CP1||abs(OP1-CP1)<=0.00002){
    CandleNode* p_Walk=this->head_can;
    int count=0;
    while(count<j){
      p_Walk=p_Walk->link;
      count++;
    }
    float OP2=stof(p_Walk->candle_data.OP);
    float HP2=stof(p_Walk->candle_data.HP);
    float LP2=stof(p_Walk->candle_data.LP);
    float CP2=stof(p_Walk->candle_data.CP);
    if(OP2<CP1&&CP2>OP1) return true;
    return false;
  }
  return false;
}
bool CandleList::isEGbearish(int i,int j){
  if(this->isEmptyCandle()||i>this->length()) return false;
  CandleNode* p_Walk=this->head_can;
  int count=0;
  while(count<i){
    p_Walk=p_Walk->link;
    count++;
  }
  float OP1=stof(p_Walk->candle_data.OP);
  float HP1=stof(p_Walk->candle_data.HP);
  float LP1=stof(p_Walk->candle_data.LP);
  float CP1=stof(p_Walk->candle_data.CP);
  if(CP1>OP1||abs(OP1-CP1)<=0.00002){
    CandleNode* p_Walk=this->head_can;
    int count=0;
    while(count<j){
      p_Walk=p_Walk->link;
      count++;
    }
    float OP2=stof(p_Walk->candle_data.OP);
    float HP2=stof(p_Walk->candle_data.HP);
    float LP2=stof(p_Walk->candle_data.LP);
    float CP2=stof(p_Walk->candle_data.CP);
    if(OP2>CP1&&CP2<OP1) return true;
    return false;
  }
  return false;

}
// CurrencyPairs Implement

void CurrencyList::clean(){
  CurrencyNode* currItem=this->head;
  while(currItem!=NULL){
    this->head=currItem->link;
    currItem=NULL;
    delete currItem;
    currItem=this->head;
  }
  this->count=0;
}

CurrencyList::~CurrencyList(){
  this->clean();
}

bool CurrencyList::find(string BC, string QC, int& idx){
  if(this->isEmpty()) {
    idx=-1;
    return false;
  }
  int index=0;
  CurrencyNode* p_Walk=this->head;
  while(p_Walk!=NULL){
    if(p_Walk->currency_data.BC.compare(BC)==0&&p_Walk->currency_data.QC.compare(QC)==0){
      idx=index;
      return true;
    }
    index++;
    p_Walk=p_Walk->link;
  }
  idx=-1;
  return false;
}

int CurrencyList::insert_currency(CurrencyData &a){
  if(this->isEmpty()){
    CurrencyNode* p_New = new CurrencyNode(a);
    this->head=p_New;
    this->count++;
    return 1;
  }else{
    CurrencyNode* p_Walk=this->head;
    while(p_Walk->link!=NULL){
      p_Walk=p_Walk->link;
    }
    CurrencyNode* p_New = new CurrencyNode(a);
    p_Walk->link=p_New;
    this->count++;
    return 1;

  }
  return -1;
}

ProcessData::ProcessData() {
  data=new CurrencyList();
}
ProcessData::~ProcessData() {
	delete data;
}
/* 
	Split the command line into instruction and its parameters
	(This version is simplified to return just the instruction only; students should rewrite to make it return instruction's parameters)
	Input:
		line: the command line
		sp: pass-by-reference parameter used as an output: return the array of strings keeping instruction and its parameter
	Output: return the number of elements in array sp.	
*/
int ProcessData::split(string line,string* &sp) {
	sp = new string[MAXSIZECODE];
	const string SEP = " ";
	int pos=0,lastpos = 0,idx = 0;
  while(pos<line.length()){
    pos = line.find(SEP,lastpos);
	  sp[idx] = line.substr(lastpos,pos-lastpos);
    lastpos=pos+1;
	  idx++;
  }
	return idx;
}

int ProcessData::process(string line) {
	string* p;
	int n = ProcessData::split(line,p);
	if (n <= 0) {
		delete [] p;
		return -1;
	}
	int res = -1;
	try {
		switch (s_mapCodeValues[p[0]]) {
			case insCode: 
				res = insert(p,n);
				break;
			case updCode:
				res = update(p,n);
        break;
			case delCode:
				res= remove(p,n);
        break;
      case stCode:
        res = stcandle(p,n);
        break;
      case mbCode:
        res=mbcandle(p,n);
        break;
      case djCode:
        res=djcandle(p,n);
        break;
      case egCode:
        res=egcandle(p,n);
        break;
			default:
				res = -1;
		}
	} catch (invalid_argument iax) {
		delete[] p;
		return res;
	}
	delete[] p;
	return res;
}

int ProcessData::insert(const string* sp,const int n) {
  if(n!=8||sp[4].compare(sp[5])>0||sp[6].compare(sp[5])>0||sp[7].compare(sp[5])>0||sp[6].compare(sp[4])>0||sp[6].compare(sp[7])>0) return -1;
  CurrencyData currency;
  currency.BC=sp[1];
  currency.QC=sp[2];
  CandleData candle;
  candle.time=sp[3];
  candle.OP=sp[4];
  candle.HP=sp[5];
  candle.LP=sp[6];
  candle.CP=sp[7];
  int idx;
  if(this->data->find(currency.BC, currency.QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
      currItem=currItem->link;
      idx--;
    }
    int index_can;
    if(currItem->currency_data.candle_list->find_can(candle.time,index_can)) {
      return currItem->currency_data.candle_list->length(); ;
    }
    currItem->currency_data.candle_list->insertCandle(candle);
    return currItem->currency_data.candle_list->length();
  }
	else{
    currency.candle_list->insertCandle(candle);
    this->data->insert_currency(currency);
    return 1;
  }
}

int ProcessData::remove(const string* sp,const int n){
  if(n<3||n>5) return -1;
  string BC=sp[1];
  string QC=sp[2];
  int idx;
  if(this->data->find(BC,QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
      currItem=currItem->link;
      idx--;
    } 
    if(n==3){
      // delete all
      int result=currItem->currency_data.candle_list->length();
      currItem->currency_data.candle_list->cleanCandle();
      delete currItem->currency_data.candle_list;
      return result;
    }
    else if(n==4){
      // delete one with time similar
      string time1=sp[3];
      int can_pos;
      if(currItem->currency_data.candle_list->find_can(time1, can_pos)){
        currItem->currency_data.candle_list->removeCandle(can_pos);
        return 1;
      }
      else{
        return 0;
      } 
    }
    else{
      string time1=sp[3];
      string time2=sp[4];
      int *a;
      int numbers;
      if(currItem->currency_data.candle_list->find_periodTime(time1,time2,a,numbers)){
        for(int i=0;i<numbers;i++){
          currItem->currency_data.candle_list->removeCandle(a[i]);
        }
        delete a;
        return numbers;
      }else {
        delete a;
        return 0;
      }
    }
  }
  return 0;
}

int ProcessData::update(const string* sp,const int n){
  if(n!=8||sp[4].compare(sp[5])>0||sp[6].compare(sp[5])>0||sp[7].compare(sp[5])>0||sp[6].compare(sp[4])>0||sp[6].compare(sp[7])>0) return -1;
  string BC= sp[1];
  string QC=sp[2];
  CandleData candle;
  string time=sp[3];
  int idx;
  if(this->data->isEmpty()) return 0;
  if(this->data->find(BC,QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
    currItem=currItem->link;
    idx--;
    }
    int index_can;
    if(currItem->currency_data.candle_list->find_can(time,index_can)){
      CandleNode* curr=currItem->currency_data.candle_list->getHeadCandle();
      while(index_can!=0){
        curr=curr->link;
        index_can--;
      }
      curr->candle_data.OP=sp[4];
      curr->candle_data.HP=sp[5];
      curr->candle_data.LP=sp[6];
      curr->candle_data.CP=sp[7];
      return 1;
    }else{
      return 0;
    } 
  }
  return 0;
}

int ProcessData::stcandle(const string* sp,const int n){
  if(n>5||n<3) return -1;
  string BC=sp[1];
  string QC=sp[2];
  int idx;
  if(this->data->find(BC,QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
      currItem=currItem->link;
      idx--;
    }
    if(n==3){
      // count all candle
      int countspin=0;
      for(int i=0;i<currItem->currency_data.candle_list->length();i++){
        if(currItem->currency_data.candle_list->isSpiningtop(i)){
          countspin++;
        }
      }
      return countspin;
    }
    else if(n==4){
      // count candle with similar time
      string time1=sp[3];
      int can_pos;
      if(currItem->currency_data.candle_list->find_can(time1, can_pos)){
        if(currItem->currency_data.candle_list->isSpiningtop(can_pos)){
          return 1;
        }
        else return 0;
      }else{
        return 0;
      } 
    }
    else{
      // count in a period time
      string time1=sp[3];
      string time2=sp[4];
      int *a;
      int numbers;
      if(currItem->currency_data.candle_list->find_periodTime(time1,time2,a,numbers)){
        int spincount=0;
        for(int i=0;i<numbers;i++){
          if(currItem->currency_data.candle_list->isSpiningtop(a[i])) {
            spincount++;
          }
        }
        return spincount;
      }else {
        return 0;    
      }
    }
  }
  return 0;
}

int ProcessData::mbcandle(const string* sp, const int n){
  if(n>5||n<3) return -1;
  string BC=sp[1];
  string QC=sp[2];
  int idx;
  if(this->data->find(BC,QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
      currItem=currItem->link;
      idx--;
    } 
    if(n==3){
      // count all candle
      int countMaru=0;
      for(int i=0;i<currItem->currency_data.candle_list->length();i++){
        if(currItem->currency_data.candle_list->isMarubozu(i)){
          countMaru++;
        }
      }
      return countMaru;
    }
    else if(n==4){
      // count candle with similar ti e
      string time1=sp[3];
      int can_pos;
      if(currItem->currency_data.candle_list->find_can(time1, can_pos)){
        if(currItem->currency_data.candle_list->isMarubozu(can_pos)){
          return 1;
        }
        else return 0;
      }else{
        return 0;
      } 
    }
    else{
      // count in a period time
      string time1=sp[3];
      string time2=sp[4];
      float t1=stof(time1);
      float t2=stof(time2);
      if(t1==t2||t1>t2) return -1;
      int *a;
      int numbers;
      if(currItem->currency_data.candle_list->find_periodTime(time1,time2,a,numbers)){
        int countMaru=0;
        for(int i=0;i<numbers;i++){
          if(currItem->currency_data.candle_list->isMarubozu(a[i])) {
            countMaru++;
          }
        }
        return countMaru;
      }else {
        return 0;   
      }
    }
  }
  return 0;
}
int ProcessData::djcandle(const string* sp, const int n){
  if(n<3||n>6) return -1;

  if(n==3){
    // count all candle
    string BC=sp[1];
    string QC=sp[2];
    int idx;
    if(this->data->find(BC,QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
    currItem=currItem->link;
    idx--;
    }
    int countDoji=0;
    for(int i=0;i<currItem->currency_data.candle_list->length();i++){
      if(currItem->currency_data.candle_list->isDJ(i)){
        countDoji++;
      }
    }
    return countDoji;
    }
  }
  if(sp[3]!="C1"&&sp[3]!="C2"&&sp[3]!="C3"&&sp[3]!="C4"){
    int n=djNonCode(sp,n);
    return n;
  }
  // n#3
  enum CodeDojiValue {C1, C2, C3, C4};
  static map<string, CodeDojiValue> s_mapCodeDojiValues = {
  	{"C1",C1},
  	{"C2",C2},
	  {"C3",C3},
	  {"C4",C4},
  };
  int result = 0;
  switch (s_mapCodeDojiValues[sp[3]]) {
  	case C1: 
	  	result = djCodeC1(sp,n);
	  	break;
  	case C2:
			result = djCodeC2(sp,n);
        break;
  	case C3:
  		result= djCodeC3(sp,n);
      break;
    case C4:
      result = djCodeC4(sp,n);
      break;
  	default:
  		result = djNonCode(sp,n);
  }
  return result;
}
int ProcessData::djCodeC1(const string* sp, const int n){
  string BC=sp[1];
  string QC=sp[2];
  int idx;
  if(this->data->find(BC,QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
      currItem=currItem->link;
      idx--;
    }  
    if(n==4){
      // count all candle
      int countDojiC1=0;
      for(int i=0;i<currItem->currency_data.candle_list->length();i++){
        if(currItem->currency_data.candle_list->isDJC1(i)){
          countDojiC1++;
        }
      }
      return countDojiC1;
    }
    else if(n==5){
      // count candle with similar time
      string time1=sp[4];
      int can_pos;
      if(currItem->currency_data.candle_list->find_can(time1, can_pos)){
        if(currItem->currency_data.candle_list->isDJC1(can_pos)){
          return 1;
        }
        else return 0;
      }else return 0; 
    }
    else{
      // count in a period time
      string time1=sp[4];
      string time2=sp[5];
      int *a;
      int numbers;
      if(currItem->currency_data.candle_list->find_periodTime(time1,time2,a,numbers)){
        int countDojiC1=0;
        for(int i=0;i<numbers;i++){
          if(currItem->currency_data.candle_list->isDJC1(a[i])) {
            countDojiC1++;
          }
        }
        delete a;
        return countDojiC1;
      }else {
        delete a;
        return 0;  
      }
    }
  }
  return 0;
}

int ProcessData::djCodeC2(const string* sp, const int n){
  string BC=sp[1];
  string QC=sp[2];
  int idx;
  if(this->data->find(BC,QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
      currItem=currItem->link;
      idx--;
    }
    if(n==4){
      // count all candle
      int countDojiC2=0;
      for(int i=0;i<currItem->currency_data.candle_list->length();i++){
        if(currItem->currency_data.candle_list->isDJC2(i)){
          countDojiC2++;
        }
      }
      return countDojiC2;
    }
    else if(n==5){
      // count candle with similar time
      string time1=sp[4];
      int can_pos;
      if(currItem->currency_data.candle_list->find_can(time1, can_pos)){
        if(currItem->currency_data.candle_list->isDJC2(can_pos)){
          return 1;
        }
        else return 0;
      }else return 0; 
    }
    else{
      // count in a period time
      string time1=sp[4];
      string time2=sp[5];
      int *a;
      int numbers;
      if(currItem->currency_data.candle_list->find_periodTime(time1,time2,a,numbers)){
        int countDojiC2=0;
        for(int i=0;i<numbers;i++){
          if(currItem->currency_data.candle_list->isDJC2(a[i])) {
            countDojiC2++;
          }
        }
        delete a;
        return countDojiC2;
      }else {
        delete a;
        return 0;  
      }
    }
  }
  return 0;
}

int ProcessData::djCodeC3(const string* sp, const int n){
  string BC=sp[1];
  string QC=sp[2];
  int idx;
  if(this->data->find(BC,QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
      currItem=currItem->link;
      idx--;
    }   
    if(n==4){
      // count all candle
      int countDojiC3=0;
      for(int i=0;i<currItem->currency_data.candle_list->length();i++){
        if(currItem->currency_data.candle_list->isDJC3(i)){
          countDojiC3++;
        }
      }
      return countDojiC3;
    }
    else if(n==5){
      // count candle with similar time
      string time1=sp[4];
      int can_pos;
      if(currItem->currency_data.candle_list->find_can(time1, can_pos)){
        if(currItem->currency_data.candle_list->isDJC3(can_pos)){
          return 1;
        }
        else return 0;
      }else return 0; 
    }
    else{
      // count in a period time
      string time1=sp[4];
      string time2=sp[5];
      int *a;
      int numbers;
      if(currItem->currency_data.candle_list->find_periodTime(time1,time2,a,numbers)){
        int countDojiC3=0;
        for(int i=0;i<numbers;i++){
          if(currItem->currency_data.candle_list->isDJC3(a[i])) {
            countDojiC3++;
          }
        }
        return countDojiC3;
      }else {
        return 0;  
      }
    }
  }
  return 0;
}
int ProcessData::djCodeC4(const string* sp, const int n){
  string BC=sp[1];
  string QC=sp[2];
  int idx;
  if(this->data->find(BC,QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
      currItem=currItem->link;
      idx--;
    }  
    if(n==4){
      // count all candle
      int countDojiC4=0;
      for(int i=0;i<currItem->currency_data.candle_list->length();i++){
        if(currItem->currency_data.candle_list->isDJC4(i)){
          countDojiC4++;
        }
      }
      return countDojiC4;
    }
    else if(n==5){
      // count candle with similar time
      string time1=sp[4];
      int can_pos;
      if(currItem->currency_data.candle_list->find_can(time1, can_pos)){
        if(currItem->currency_data.candle_list->isDJC4(can_pos)){
          return 1;
        }
        else return 0;
      }else return 0; 
    }
    else{
      // count in a period time
      string time1=sp[4];
      string time2=sp[5];
      int *a;
      int numbers;
      if(currItem->currency_data.candle_list->find_periodTime(time1,time2,a,numbers)){
        int countDojiC4=0;
        for(int i=0;i<numbers;i++){
          if(currItem->currency_data.candle_list->isDJC4(a[i])) {
            countDojiC4++;
          }
        }
        delete a;
        return countDojiC4;
      }else {
        delete a;
        return 0;  
      }
    }
  }
  return 0;
}
int ProcessData::djNonCode(const string* sp, const int n){
  string BC=sp[1];
  string QC=sp[2];
  int idx;
  if(this->data->find(BC,QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
      currItem=currItem->link;
      idx--;
    }
    if(n==4){
      // count candle with similar ti e
      string time1=sp[3];
      int can_pos;
      if(currItem->currency_data.candle_list->find_can(time1, can_pos)){
        if(currItem->currency_data.candle_list->isDJ(can_pos)){
          return 1;
        }
        else return 0;
      } else{
        return 0;
      } 
    }
    else{
      // count in a period time
      string time1=sp[3];
      string time2=sp[4];
      int *a;
      int numbers;
      if(currItem->currency_data.candle_list->find_periodTime(time1,time2,a,numbers)){
        int countDoji=0;
        for(int i=0;i<numbers;i++){
          if(currItem->currency_data.candle_list->isDJ(a[i])){
            countDoji++;
          }
        }
        delete a;
        return countDoji;
      }else {
        delete a;
        return 0;
      }
    }
  }
  return 0;
}
int ProcessData::egcandle(const string*sp,const int n ){
  if(n<3||n>6) return -1;
  string BC=sp[1];
  string QC=sp[2];
  int idx;
  if(this->data->find(BC,QC,idx)){
    CurrencyNode* currItem=this->data->getHead();
    while(idx!=0){
      currItem=currItem->link;
      idx--;
    }
    if(n==3){
      int countEG=0;
      for(int i=0;i<currItem->currency_data.candle_list->length()-1;i++){
        if(currItem->currency_data.candle_list->isEGbearish(i,i+1)||currItem->currency_data.candle_list->isEGbullish(i,i+1)){
          countEG++;
        }
      }
      return countEG;
    }
    else if(n==4){
      if(sp[3]=="C1"){
        int countEG=0;
        for(int i=0;i<currItem->currency_data.candle_list->length()-1;i++){
          if(currItem->currency_data.candle_list->isEGbullish(i,i+1)){
            countEG++;
          }
        }
        return countEG;
      }
      else if(sp[3]=="C2"){
        int countEG=0;
        for(int i=0;i<currItem->currency_data.candle_list->length()-1;i++){
          if(currItem->currency_data.candle_list->isEGbearish(i,i+1)){
            countEG++;
          }
        }
        return countEG;
      }
    }
    else if(n==6){
      if(sp[3]=="C1"){
        string time1=sp[4];
        string time2=sp[5];
        if(time1.compare(time2)>=0) return -1;
        int *a;
        int numbers;
        if(currItem->currency_data.candle_list->find_periodTime(time1,time2,a,numbers)){
          int countEG=0;
          for(int i=0;i<numbers-1;i++){
            if(currItem->currency_data.candle_list->isEGbullish(a[i],a[i+1])) {
              countEG++;
            }
          }
          return countEG;
        }else {
          return 0;
        }
      }
      else if(sp[3]=="C2"){
        string time1=sp[4];
        string time2=sp[5];
        if(time1.compare(time2)>=0) return -1;
        int *a;
        int numbers;
        if(currItem->currency_data.candle_list->find_periodTime(time1,time2,a,numbers)){
          int countEG=0;
          for(int i=0;i<numbers-1;i++){
            if(currItem->currency_data.candle_list->isEGbearish(a[i],a[i+1])) {
              countEG++;
            }
          }
          return countEG;
        }else {
          return 0;
        }
      }
    }
  }
  return 0;
}
